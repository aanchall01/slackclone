import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import MessageList from './messageList';
import SendMessage from './sendMessage';

// Sample data for testing
const sampleMessages = {
  general: [
    { sender: 'Alice', content: 'Hey everyone!' },
    { sender: 'Bob', content: 'Hello Alice!' },
  ],
  random: [
    { sender: 'Charlie', content: 'Did you see that game last night?' },
  ],
  // More channels and messages as needed
};

const Channel = () => {
  const [messages, setMessages] = useState([]);
  const { channelName } = useParams();

  useEffect(() => {
    setMessages(sampleMessages[channelName.toLowerCase()] || []);
  }, [channelName]);

  const handleSendMessage = (newMessageContent) => {
    setMessages([...messages, { sender: 'User', content: newMessageContent }]);
  };

  return (
    <div style={styles.container}>
      <h3 style={styles.header}>Channel: {channelName}</h3>
      <div style={styles.messageContainer}>
        <MessageList messages={messages} />
      </div>
      <SendMessage onSendMessage={handleSendMessage} />
    </div>
  );
};

const headerHeight = '50px'; // Adjust as per actual header height
const sendMessageHeight = '60px'; // Adjust as per SendMessage component's height

const styles = {
  container: {
    display: 'flex',
    flexDirection: 'column',
    height: '100vh',
    maxWidth: '1400px',
    margin: 'auto',
    backgroundColor: '#f4f4f4',
  },
  header: {
    height: headerHeight,
    padding: '15px',
    backgroundColor: '#57aaa0',
    color: '#fff',
    fontSize: '22px',
  },
  messageContainer: {
    flex: 1,
    overflowY: 'auto',
    padding: '10px',
    maxHeight: `calc(100vh - ${headerHeight} - ${sendMessageHeight})`, // Adjusting height
  },
  // Add or adjust any other styles as necessary
};

export default Channel;
